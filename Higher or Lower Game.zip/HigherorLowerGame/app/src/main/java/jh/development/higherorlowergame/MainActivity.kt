package jh.development.higherorlowergame

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.HapticFeedbackConstants
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import kotlin.random.Random

class MainActivity : AppCompatActivity() {

    private var higherBtn : Button? = null
    private var displayNum : TextView? = null
    private var lowerBtn : Button? = null
    private var scoreTV : TextView? = null

    private var score : Int = 0

    //target and current numbers
    private var targetNum = 0
    private var currentNum = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        higherBtn = findViewById(R.id.higherButton)
        displayNum = findViewById(R.id.displayNumber)
        lowerBtn = findViewById(R.id.lowerButton)
        scoreTV = findViewById(R.id.score)

        generateNewNumbers()
        displayNum?.text = currentNum.toString()

        higherBtn?.setOnClickListener {
            if(targetNum > currentNum){
                higherBtn?.performHapticFeedback(HapticFeedbackConstants.CONFIRM)
                score += 1
                generateNewNumbers()
            }else {
                higherBtn?.performHapticFeedback(HapticFeedbackConstants.REJECT)
                score = 0
                generateNewNumbers()
            }
            scoreTV?.text = score.toString()
            displayNum?.text = currentNum.toString()
        }
        lowerBtn?.setOnClickListener {
            if(targetNum > currentNum){
                lowerBtn?.performHapticFeedback(HapticFeedbackConstants.CONFIRM)
                score += 1
                generateNewNumbers()
            }else {
                lowerBtn?.performHapticFeedback(HapticFeedbackConstants.REJECT)
                score = 0
                generateNewNumbers()
            }
            scoreTV?.text = score.toString()
            displayNum?.text = currentNum.toString()
        }
    }

    private fun generateNewNumbers(){
        targetNum = Random.nextInt(100 - 1)
        currentNum = Random.nextInt(100 - 1)
    }
}